This is a customized software designed for Joel Fernan and made by Aiotik, LLC with the collaboration of the Eng. Jes�s Soto

Instructions:

- Run the MetadataEditor_setup.exe file and follow the steps shown.


**Notes:

- In order for this software to understand the tags (System.keywords), the user in the excel spreadsheet should use (;) instead of (,).

- The format accepted by this software on the spreadsheet is the following:

VIDEO NAME|TITLE|SUBTITLES|RATING|TAGS|COMMENTS|AUTHOR URL|PROMOTION URL

- It is recommended to use this exact same format (exact same letters as well), in order for this software to run accordingly.

- Keep the video's folder closed while the program edits the metadata

